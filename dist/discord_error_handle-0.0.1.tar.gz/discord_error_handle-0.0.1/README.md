# convert int str in list
 Simple Converter Convert All int and string in a list


This converter allows you to convert all string in a list into a list that contains everything you input except for the type of the thing inside it is int. This action can be reverse by converting all int to a string again.